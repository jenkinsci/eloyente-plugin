function sayHi(){
   alert("Hi! Welcome to the great world of Jenkins!");
}

function checkConnection(){
    
}